(function($) {
  'use strict';
  $("my-awesome-dropzone").dropzone({
    url: "urbanui.com/"
  });
})(jQuery);